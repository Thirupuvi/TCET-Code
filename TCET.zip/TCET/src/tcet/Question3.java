package tcet;
import java.util.HashMap;


public class Question3 {
	String input="This is a test string.This string for testing.";
	String[] words=input.toLowerCase().split(" ");
	HashMap<String, Integer> wrdcnt=new HashMap<>();
	for (String word:words) {
		
	}
	

}
